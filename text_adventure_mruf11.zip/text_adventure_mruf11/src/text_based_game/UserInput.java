package text_based_game;


import java.util.Random;
import java.util.Scanner;

public class UserInput {
    public static void main(String[] args) {
// ############################################################
// This is the fighting portion of the game. Feel free to customize or add input. Just a bare bones combat system!

        // objects
        Scanner in = new Scanner(System.in);
        // rand gives random number between 0 and given parameter
        Random rand = new Random();

        // Game Variables
        String[] enemies = { "Skeleton", "Zombie", "Warrior", "Assassin"};
        int maxEnemyHealth = 75;
        int enemyAttackDamage = 25;

        // Player Variables
        int health = 100;
        int attack = 50;
        int numHealthPotions = 3;
        int healthPotionHealAmount = 30;
        int healthPotionDropChance = 50;  // Percentage

        boolean running = true;

        System.out.println("Welcome to the Dungeon!");


        GAME: // Using the GAME: label, makes the first while loop the parent loop,
              // so I can repeat the enemy encounter system
        while (running) {
            System.out.println("----------------------------------------");

            int enemyHealth = rand.nextInt(maxEnemyHealth);
            String enemy = enemies[rand.nextInt(enemies.length)];
            System.out.println("\t# A " + enemy + " has appeared! #\n");

            while(enemyHealth > 0) {
                System.out.println("\tYour HP: " + health);
                System.out.println("\t " + enemy + "'s HP: " + enemyHealth);
                System.out.println("\n\tWhat would you like to do?");
                System.out.println("\t1. Attack");
                System.out.println("\t2. Drink Health Potion");
                System.out.println("\t3. Run!");

                String input = in.nextLine().toLowerCase();

                if (input.contains("attack")) {
                    int damageDealt = rand.nextInt(attack);
                    int damageTaken = rand.nextInt(enemyAttackDamage);

                    enemyHealth -= damageDealt;
                    health -= damageTaken;

                    System.out.println("\t >You strike the " + enemy + " for " + damageDealt + " damage.");
                    System.out.println("\t >You took " + damageTaken + " damage during the fight!");

                    if (health < 1) {
                        System.out.println("\t > You have taken too much damage! You are too weak to go on...");
                        health = 100;
                        break;
                    }

                } else if (input.contains("drink")) {
                    if (numHealthPotions > 0) {
                        health += healthPotionHealAmount;
                        numHealthPotions --;
                        System.out.println("\t >You drink a health potion, healing yourself for " + healthPotionHealAmount + "HP."
                         + "\n\t >You now have " + health + " HP." + "\n\t> You have " + numHealthPotions + " health potions left.\n");
                    } else {
                        System.out.println("\t> You have no health potions left! Damage more enemies for a chance to get one!");
                    }

                } else if (input.contains("run")) {
                    System.out.println("\tYou run away from the " + enemy + "!");
                    // Using continue GAME: breaks out of the while loop you are in and goes to the parent loop
                    continue GAME;


                } else {
                    System.out.println("\tInvalid prompt. Try Again!");
                }

                // Checking to see if you died in battle
                if (health < 1) {
                    System.out.println("You limp out of the dungeon, weak from battle.");
                    break;
                }

            }
            // if here, then you defeated the enemy. Display stats from after battle
            System.out.println("----------------------------------------");
            System.out.println("  #  The " + enemy + " was defeated!  # ");
            System.out.println("  #  You have " + health + " HP left after the battle.  #");

            // Calculating drop chance for potion
            if (rand.nextInt(100) < healthPotionDropChance) {
                numHealthPotions ++;
                System.out.println("  #  The " + enemy + " dropped a health potion!  #");
                System.out.println("  #  You now have " + numHealthPotions + " health potion(s) in your inventory.  #");
            }
            System.out.println("----------------------------------------");
            System.out.println("What would you like to do now? Enter 1 or 2 to continue.");
            System.out.println("1. Continue Fighting");
            System.out.println("2. Go Exploring");

            String input = in.nextLine();

            while (!input.equals("1") && !input.equals("2")) {
                System.out.println("Invalid Command!");
                input = in.nextLine();
            }

            if (input.equals("1")) {
                System.out.println("You continue fighting!");
            } else if (input.equals("2)")) { // Break out of the loop
                System.out.println("The enemies seem to have vanished from the dungeon.... You continue exploring.");
                break;
            }

        }


    } // end of main
} // last line
